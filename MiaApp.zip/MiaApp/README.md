# MiaApp

App macOS in SwiftUI compilata gratis da GitHub Actions: niente Xcode sul Mac.

## Primo avvio

1. Crea un repository **pubblico** su GitHub (build illimitate gratis) e carica questi file
   (pulsante "Add file → Upload files", trascinando anche la cartella `.github`).
2. Vai nella scheda **Actions**: la build parte da sola a ogni modifica sul branch `main`
   (oppure avviala a mano con "Run workflow").
3. Finita la build (3-5 minuti), apri l'esecuzione e scarica **MiaApp** da *Artifacts*.
4. Decomprimi (due volte: zip dentro zip), trascina `MiaApp.app` in Applicazioni.
5. Primo avvio: clic destro → **Apri** → **Apri**. In alternativa da Terminale:
   `xattr -cr /Applications/MiaApp.app`

## Modificare l'app

- Apri il repository e premi il tasto `.` → si apre VS Code nel browser.
- Il codice dell'interfaccia è in `Sources/MiaApp/ContentView.swift`.
- Fai commit: GitHub ricompila e ti dà la nuova versione.
- Se la build fallisce, l'errore è nel log della scheda Actions.

## Personalizzare

- **Nome/versione**: `Info.plist` (`CFBundleName`, `CFBundleShortVersionString`).
- **Icona**: aggiungi un file `AppIcon.icns` nella cartella principale, il workflow lo usa da solo.
- Se rinomini l'app, cambia `MiaApp` anche in `Package.swift`, nella cartella `Sources/` e nel workflow.
